import socket

HOST = '127.0.0.1'
PORT = 5001

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    print(f"Connected to server {HOST}:{PORT}")
    while True:
        msg = input("Enter message: ")
        s.sendall(msg.encode())
        data = s.recv(1024)
        print(f"Server replied: {data.decode()}")
